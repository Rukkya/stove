# stove > 2025-04-30 5:00pm
https://universe.roboflow.com/na-plfxb/stove-fglp1

Provided by a Roboflow user
License: CC BY 4.0

